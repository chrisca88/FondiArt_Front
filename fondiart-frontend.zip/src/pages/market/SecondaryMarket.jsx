// src/pages/market/SecondaryMarket.jsx
import { useEffect, useMemo, useState } from 'react'
import { useSelector } from 'react-redux'
import { buyListing } from '../../services/mockMarket.js'
import { getPortfolio } from '../../services/mockWallet.js'
import { useNavigate } from 'react-router-dom'
import ConfirmDialog from '../../components/ui/ConfirmDialog.jsx'
import authService from '../../services/authService.js'

export default function SecondaryMarket(){
  const user = useSelector(s => s.auth.user)
  const navigate = useNavigate()

  const [loading, setLoading] = useState(true)
  const [listings, setListings] = useState([])
  const [portfolio, setPortfolio] = useState({ cashARS: 0, items: [] })
  const [q, setQ] = useState('')

  // Saldo real de la cuenta (desde backend)
  const [accountBalance, setAccountBalance] = useState(0)

  // Modal crear
  const [open, setOpen] = useState(false)
  const [form, setForm] = useState({ artworkId: '', price: '', qty: 1 })

  // Tokens reales del usuario (desde backend real)
  const [userTokens, setUserTokens] = useState([])
  const [tokensLoading, setTokensLoading] = useState(false)
  const [tokensError, setTokensError] = useState('')

  // token seleccionado actualmente en el modal
  const selectedToken = useMemo(() => {
    return userTokens.find(t => String(t.token_id) === String(form.artworkId))
  }, [userTokens, form.artworkId])

  // Confirm dialog (comprar / cancelar)
  const [confirm, setConfirm] = useState({ open:false, mode:null, listing:null, loading:false })
  const [buyQty, setBuyQty] = useState(1)

  // <-- NUEVO: error mostrado dentro del modal de confirmación -->
  const [modalError, setModalError] = useState('')

  // Avisos simples
  const [notice, setNotice] = useState(null)
  const showNotice = (msg, type='ok') => {
    setNotice({ msg, type }); setTimeout(()=> setNotice(null), 1600)
  }

  // === obtener órdenes abiertas desde backend real (AJUSTADO A .results) ===
  async function fetchOpenOrders() {
    try {
      setLoading(true)
      const res = await authService.client.get('/finance/sell-orders/open/')
      const raw = res?.data?.results || []
      const mapped = raw.map(o => ({
        id: o.id,
        symbol: o.token_symbol,
        title: o.token_name,
        price: o.price,
        qty: o.quantity,
        sellerId: o.user,
        sellerName: o.user_name,
        status: o.status,
      }))
      setListings(mapped)
    } catch (err) {
      console.error('Error cargando órdenes:', err)
      showNotice('Error al cargar órdenes del mercado', 'err')
      setListings([])
    } finally {
      setLoading(false)
    }
  }

  // === obtener saldo real de cuenta ===
  async function fetchAccount() {
    try {
      const res = await authService.client.get('/finance/cuenta/')
      const bal = Number(res?.data?.balance || 0)
      setAccountBalance(bal)
    } catch (err) {
      console.error('Error cargando saldo:', err)
      setAccountBalance(0)
    }
  }

  // Carga inicial de órdenes abiertas, portfolio y saldo
  useEffect(() => {
    let alive = true
    async function load() {
      await fetchOpenOrders()
      const pf = await getPortfolio(user)
      if (alive) {
        setPortfolio(pf)
      }
      await fetchAccount()
    }
    load()
    return () => { alive = false }
  }, [user])

  const mySellables = useMemo(
    () => (portfolio.items || []).filter(it => Number(it.qty) > 0),
    [portfolio]
  )

  const filtered = useMemo(()=>{
    const s = q.trim().toLowerCase()
    if (!s) return listings
    return listings.filter(l =>
      l.symbol.toLowerCase().includes(s) ||
      l.title.toLowerCase().includes(s) ||
      l.sellerName.toLowerCase().includes(s)
    )
  }, [q, listings])

  // Cuando se abre el modal, buscamos los tokens reales del usuario autenticado
  useEffect(() => {
    let alive = true
    async function fetchTokens() {
      if (!open) return
      try {
        setTokensLoading(true)
        setTokensError('')
        const res = await authService.client.get(`/finance/users/${user.id}/tokens/`)
        if (!alive) return
        const data = res?.data?.results || []
        setUserTokens(Array.isArray(data) ? data : [])
      } catch (err) {
        if (!alive) return
        const msg = err?.response?.data?.message || err?.message || 'Error al cargar tokens'
        setTokensError(msg)
        setUserTokens([])
      } finally {
        if (!alive) return
        setTokensLoading(false)
      }
    }
    fetchTokens()
    return ()=>{ alive = false }
  }, [open, user?.id])

  // Crear nueva publicación
  async function handleCreate(e){
    e.preventDefault()

    const chosen = selectedToken
    if (!chosen) {
      return showNotice('Seleccioná un token válido', 'err')
    }

    const desiredQty = Number(form.qty || 1)
    const maxAllowed = Number(chosen.quantity || 0)
    if (desiredQty < 1 || desiredQty > maxAllowed){
      return showNotice('Cantidad inválida (supera lo que tenés)', 'err')
    }

    try{
      await authService.client.post('/finance/sell-orders/', {
        token: chosen.token_id,
        user: user.id,
        quantity: desiredQty,
        price: form.price
      })

      await fetchOpenOrders()
      const pf = await getPortfolio(user)
      setPortfolio(pf)

      // también refresco saldo real por si hay cambios
      await fetchAccount()

      setOpen(false)
      setForm({ artworkId:'', price:'', qty:1 })
      showNotice('Publicación creada')
    }catch(err){
      showNotice(err?.response?.data?.message || err.message || 'Error al publicar', 'err')
    }
  }

  const askCancel = (listing) =>
    setConfirm({ open:true, mode:'cancel', listing, loading:false })
  const askBuy = (listing) => {
    setBuyQty(1)
    setModalError('') // limpiamos error previo al abrir modal
    setConfirm({ open:true, mode:'buy', listing, loading:false })
  }
  const closeConfirm = () => {
    setModalError('') // limpiamos error al cerrar modal
    setConfirm({ open:false, mode:null, listing:null, loading:false })
  }

  // Ejecutar confirmación (compra / cancelar)
  async function doConfirm(){
    const l = confirm.listing
    if (!l) return
    try{
      if (confirm.mode === 'buy') {
        // Validar saldo con comisión del 2% antes de llamar al backend
        const qtyNum = Math.floor(Number(buyQty) || 0)
        const subtotal = Number(l.price) * qtyNum
        const fee = subtotal * 0.02
        const totalWithFee = subtotal + fee

        if (totalWithFee > accountBalance) {
          // mostramos el error DENTRO DEL MODAL, no como notice externo
          setModalError('Saldo insuficiente para completar la compra (incluye 2% de comisión).')
          return
        }

        setConfirm(c=>({ ...c, loading:true }))
        setModalError('')

        // COMPRAR via backend real
        await authService.client.post('/finance/buy-order/', {
          sell_order_id: l.id,
          quantity: qtyNum
        })

        showNotice('Compra realizada')
      } else {
        setConfirm(c=>({ ...c, loading:true }))
        // CANCELAR PUBLICACIÓN (orden propia)
        await authService.client.patch(`/finance/sell-orders/${l.id}/`, {
          status: 'cancelada'
        })
        showNotice('Publicación cancelada')
      }

      await fetchOpenOrders()
      const pf = await getPortfolio(user)
      setPortfolio(pf)
      await fetchAccount()

      closeConfirm()
    }catch(err){
      setConfirm(c=>({ ...c, loading:false }))
      // mostramos cualquier error del backend dentro del modal también
      setModalError(err?.response?.data?.message || err.message || 'Ocurrió un error')
    }
  }

  const fmt = (n)=> Number(n||0).toLocaleString('es-AR')

  // Validaciones compra parcial (confirm dialog existente)
  const maxQty = confirm.listing ? Number(confirm.listing.qty) : 1
  const qtyNum = Math.floor(Number(buyQty) || 0)
  const qtyValid = confirm.mode !== 'buy' || (qtyNum >= 1 && qtyNum <= maxQty)
  const buyTotal = (confirm.mode === 'buy' && confirm.listing && qtyValid)
    ? Number(confirm.listing.price) * qtyNum
    : 0

  // ---- comisión 2% y total final mostrado en el modal ----
  const feeRate = 0.02
  const buyFee = (confirm.mode === 'buy' && confirm.listing && qtyValid) ? buyTotal * feeRate : 0
  const grandTotal = (confirm.mode === 'buy' && confirm.listing && qtyValid) ? buyTotal + buyFee : 0
  // --------------------------------------------------------

  // límite de cantidad para publicar en el modal, basado en lo que el usuario tiene
  const maxForSelectedToken = selectedToken ? Number(selectedToken.quantity || 0) : null

  return (
    <section className="min-h-[calc(100vh-4rem)] bg-gradient-to-b from-white to-slate-50">
      <div className="section-frame py-8 space-y-6">

        {/* Aviso */}
        {notice && (
          <div className={`rounded-xl border px-4 py-2 text-sm ${
            notice.type==='err'
              ? 'bg-red-50 border-red-200 text-red-700'
              : 'bg-emerald-50 border-emerald-200 text-emerald-700'
          }`}>
            {notice.msg}
          </div>
        )}

        <div className="flex flex-col lg:flex-row lg:items-end lg:justify-between gap-4">
          <div>
            <p className="eyebrow">Mercado</p>
            <h1 className="text-3xl sm:text-4xl font-extrabold tracking-tight">Mercado secundario</h1>
            <p className="lead mt-2 max-w-2xl">Compra y venta entre usuarios de tokens de obras.</p>
          </div>

          <div className="flex items-center gap-3">
            <div className="text-right">
              <div className="text-xs uppercase text-slate-500">Tu saldo</div>
              <div className="text-lg font-extrabold">${fmt(accountBalance)}</div>
            </div>
            <button className="btn btn-primary" onClick={()=> setOpen(true)}>
              Nueva publicación
            </button>
          </div>
        </div>

        {/* Filtros */}
        <div className="card-surface p-4 flex flex-wrap items-center gap-4">
          <div className="relative">
            <input
              className="input pr-10 w-72"
              placeholder="Buscar por símbolo, título o vendedor…"
              value={q}
              onChange={e=>setQ(e.target.value)}
            />
            <span className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 text-slate-400">
              <SearchIcon className="h-5 w-5"/>
            </span>
          </div>
          <button className="btn btn-outline" onClick={()=> navigate('/wallet')}>Ir a mi wallet</button>
        </div>

        {/* Tabla de órdenes */}
        <div className="card-surface p-0 overflow-hidden">
          <div className="grid grid-cols-12 px-4 py-3 text-xs font-semibold uppercase tracking-wider text-slate-500">
            <div className="col-span-4">Token</div>
            <div className="col-span-2 text-right">Precio</div>
            <div className="col-span-2 text-right">Cantidad</div>
            <div className="col-span-2 text-right">Vendedor</div>
            <div className="col-span-2 text-right">Acción</div>
          </div>
          <div className="h-px bg-slate-200/70" />

          {loading ? (
            <RowsSkeleton/>
          ) : filtered.length === 0 ? (
            <div className="p-6 text-center text-slate-600">No hay publicaciones.</div>
          ) : (
            filtered.map(l => (
              <div key={l.id} className="grid grid-cols-12 items-center px-4 py-3">
                <div className="col-span-4">
                  <div className="font-semibold text-slate-900 leading-tight">{l.symbol}</div>
                  <div className="text-xs text-slate-500 line-clamp-1">{l.title}</div>
                </div>
                <div className="col-span-2 text-right text-slate-700">${fmt(l.price)}</div>
                <div className="col-span-2 text-right">{l.qty}</div>
                <div className="col-span-2 text-right text-slate-600">{l.sellerName}</div>
                <div className="col-span-2 text-right">
                  {l.sellerId === user.id ? (
                    <button className="btn btn-outline btn-sm w-[110px]" onClick={()=>askCancel(l)}>
                      Cancelar
                    </button>
                  ) : (
                    <button className="btn btn-primary btn-sm w-[110px]" onClick={()=>askBuy(l)}>
                      Comprar
                    </button>
                  )}
                </div>
              </div>
            ))
          )}
        </div>

        {/* Modal nueva publicación */}
        {open && (
          <div className="fixed inset-0 z-[60] bg-black/40 grid place-items-center p-4" onClick={()=> setOpen(false)}>
            <div className="w-full max-w-lg rounded-2xl bg-white shadow-xl p-6" onClick={e=>e.stopPropagation()}>
              <h2 className="text-xl font-bold mb-1">Nueva publicación</h2>
              <p className="text-sm text-slate-600 mb-4">Elegí el token que querés vender y definí precio y cantidad.</p>

              <form onSubmit={handleCreate} className="space-y-4">
                <label className="block">
                  <span className="block text-sm font-medium mb-1">Token</span>

                  <select
                    className="select w-full"
                    value={form.artworkId}
                    onChange={e=> setForm(f=>({ ...f, artworkId: e.target.value }))}
                    disabled={tokensLoading}
                  >
                    <option value="">
                      {tokensLoading
                        ? 'Cargando...'
                        : tokensError
                          ? 'Error al cargar tokens'
                          : 'Seleccionar…'}
                    </option>

                    {!tokensLoading && !tokensError && userTokens.map(t => (
                      <option key={t.token_id} value={t.token_id}>
                        {t.token_name} (tenés {t.quantity})
                      </option>
                    ))}
                  </select>

                  {tokensError && (
                    <div className="text-xs text-red-600 mt-1">{tokensError}</div>
                  )}

                  {selectedToken && !tokensError && (
                    <div className="mt-2 text-xs text-slate-600">
                      El precio de adquisición de tus tokens fue ${Number(selectedToken.unit_price || 0).toLocaleString('es-AR')} ARS
                    </div>
                  )}
                </label>

                <div className="grid grid-cols-2 gap-4">
                  <label className="block">
                    <span className="block text-sm font-medium mb-1">Precio (ARS por token)</span>
                    <input
                      className="input w-full"
                      type="number" step="0.01" min="0"
                      value={form.price}
                      onChange={e=> setForm(f=>({ ...f, price: e.target.value }))}
                      placeholder="Ej: 15000"
                    />
                  </label>
                  <label className="block">
                    <span className="block text-sm font-medium mb-1">Cantidad</span>
                    <input
                      className="input w-full"
                      type="number"
                      step="1"
                      min="1"
                      max={maxForSelectedToken ?? undefined}
                      value={form.qty}
                      onChange={e=> {
                        const raw = e.target.value
                        let next = raw
                        if (maxForSelectedToken != null) {
                          const asNum = Number(raw)
                          if (!Number.isNaN(asNum) && asNum > maxForSelectedToken) {
                            next = String(maxForSelectedToken)
                          }
                        }
                        setForm(f=>({ ...f, qty: next }))
                      }}
                    />
                    {maxForSelectedToken != null && (
                      <div className="mt-1 text-xs text-slate-500">
                        Máximo disponible: {maxForSelectedToken}
                      </div>
                    )}
                  </label>
                </div>

                <div className="flex items-center justify-end gap-3 pt-2">
                  <button type="button" className="btn btn-outline" onClick={()=> setOpen(false)}>Cerrar</button>
                  <button type="submit" className="btn btn-primary">Publicar</button>
                </div>
              </form>
            </div>
          </div>
        )}

        {/* Confirmaciones profesionales (con compra parcial) */}
        <ConfirmDialog
          open={confirm.open}
          onCancel={closeConfirm}
          onConfirm={doConfirm}
          loading={confirm.loading}
          confirmDisabled={!qtyValid}
          tone={confirm.mode === 'cancel' ? 'danger' : 'primary'}
          title={confirm.mode === 'buy' ? 'Confirmar compra' : 'Cancelar publicación'}
          confirmText={confirm.mode === 'buy' ? 'Confirmar compra' : 'Confirmar'}
          cancelText="Volver"
          description={
            confirm.listing
              ? (confirm.mode === 'buy'
                  ? 'Estás a punto de comprar esta publicación.'
                  : 'Esta acción devolverá los tokens a tu wallet.')
              : ''
          }
        >
          {confirm.listing && (
            <div className="text-sm text-slate-700 space-y-3">
              <div><span className="font-medium">Token:</span> {confirm.listing.symbol} — {confirm.listing.title}</div>
              <div className="grid grid-cols-2 gap-3 items-end">
                <div>
                  <div className="text-xs uppercase text-slate-500 mb-1">Precio por token</div>
                  <div className="font-semibold">${fmt(confirm.listing.price)}</div>
                </div>
                {confirm.mode === 'buy' ? (
                  <label className="block">
                    <span className="block text-xs uppercase text-slate-500 mb-1">Cantidad a comprar</span>
                    <input
                      type="number"
                      min={1}
                      max={maxQty}
                      step="1"
                      className="input w-28"
                      value={buyQty}
                      onChange={e => setBuyQty(e.target.value)}
                    />
                    <div className="mt-1 text-xs text-slate-500">Disponibles: {maxQty}</div>
                  </label>
                ) : (
                  <div>
                    <div className="text-xs uppercase text-slate-500 mb-1">Cantidad publicada</div>
                    <div className="font-semibold">{confirm.listing.qty}</div>
                  </div>
                )}
              </div>

              {confirm.mode === 'buy' && (
                <div className="space-y-1">
                  <div>
                    <span className="font-medium">Subtotal:</span>{' '}
                    {qtyValid ? `$${fmt(buyTotal)}` : <span className="text-slate-500">—</span>}
                  </div>
                  <div>
                    <span className="font-medium">Comisión (2%):</span>{' '}
                    {qtyValid ? `$${fmt(buyFee)}` : <span className="text-slate-500">—</span>}
                  </div>
                  <div>
                    <span className="font-medium">Total final:</span>{' '}
                    {qtyValid ? `$${fmt(grandTotal)}` : <span className="text-slate-500">—</span>}
                  </div>

                  {modalError && (
                    <div className="text-xs text-red-600 font-medium mt-2">
                      {modalError}
                    </div>
                  )}
                </div>
              )}
            </div>
          )}
        </ConfirmDialog>

      </div>
    </section>
  )
}

function RowsSkeleton(){
  return (
    <>
      {Array.from({length:4}).map((_,i)=>(
        <div key={i} className="grid grid-cols-12 items-center px-4 py-3">
          <div className="col-span-4"><div className="h-4 w-40 bg-slate-200/70 animate-pulse rounded" /></div>
          <div className="col-span-2 text-right"><div className="h-4 w-16 bg-slate-200/70 animate-pulse rounded ml-auto"/></div>
          <div className="col-span-2 text-right"><div className="h-4 w-10 bg-slate-200/70 animate-pulse rounded ml-auto"/></div>
          <div className="col-span-2 text-right"><div className="h-4 w-28 bg-slate-200/70 animate-pulse rounded ml-auto"/></div>
          <div className="col-span-2 text-right"><div className="h-7 w-[110px] bg-slate-200/70 animate-pulse rounded ml-auto"/></div>
        </div>
      ))}
    </>
  )
}

function SearchIcon(props){ return (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" {...props}>
    <circle cx="11" cy="11" r="8"/><path d="M21 21l-3.5-3.5"/>
  </svg>
)}
